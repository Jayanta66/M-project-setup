package com.example.M_Client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
